dialog_options = {"dialog_option_1_vm_target_name"=>"new-instance-2", "Array::dialog_tag_0_yale_projects"=>"Classification::45000000000131", "request"=>"clone_to_service"}
tags_regex = /^*dialog_tag_\d*_(.*)/
dialog_options.each do |k, v|
 if tags_regex =~ k
    tag_category0 = Regexp.last_match[0].to_sym
    type_tag, real_tag = tag_category0.to_s.split("::")
    tag_category = Regexp.last_match[1].to_sym
    tag_value = v.downcase
    puts "#{tag_category0} #{real_tag} #{tag_category} => #{tag_value}"
    puts Regexp.last_match.inspect
 else
    puts "??"
 end
end
